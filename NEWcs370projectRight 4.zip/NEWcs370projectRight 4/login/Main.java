import java.sql.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean loggedIn = false;

        System.out.println("Welcome to Remmy!");

        while (!loggedIn) {
            System.out.print("Enter your username: ");
            String inputUsername = scanner.nextLine();
            System.out.print("Enter your password: ");
            String inputPassword = scanner.nextLine();

            if (authenticateUser(inputUsername, inputPassword)) {
                System.out.println("Login successful.");
                loggedIn = true;
            } else {
                System.out.println("Invalid username or password.");
                System.out.print("Would you like to register this account? (yes/no): ");
                String choice = scanner.nextLine().trim().toLowerCase();

                if (choice.equals("yes") || choice.equals("y")) {
                    if (registerUser(inputUsername, inputPassword)) {
                        System.out.println("Registration complete. You are now logged in.");
                        loggedIn = true;
                    } else {
                        System.out.println("Registration failed. Try again.");
                    }
                } else {
                    System.out.println("Goodbye.");
                    break;
                }
            }
        }

        scanner.close();
    }

    public static boolean authenticateUser(String username, String password) {
        try (Connection conn = DB.connect()) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    public static boolean registerUser(String username, String password) {
        try (Connection conn = DB.connect()) {
            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            if (e.getMessage().contains("duplicate key")) {
                System.out.println("Username already exists.");
            } else {
                System.out.println("Error: " + e.getMessage());
            }
            return false;
        }
    }
}
