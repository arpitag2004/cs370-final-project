import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class User implements Serializable {
    private String firstName;
    private String lastName;
    private String username;
    private String password;

    private List<PantryItem> pantryItems = new ArrayList<>();
    private Map<String, Integer> savedRecipes = new HashMap<>(); // Maps recipe names to their total calories

    private int calorieTarget;

    // --- New Profile Fields ---
    private int age = 0;
    private double weightLbs = 0.0;
    private int heightFeet = 0;
    private int heightInches = 0;
    private String sex = ""; // "Male" or "Female"
    private String activityLevel = ""; // "Sedentary", etc.
    private String goalType = ""; // "Lose", "Maintain", "Gain"

    // --- Constructor ---
    public User(String firstName, String lastName, String username, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
    }

    // --- Basic Getters ---
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }

    // --- Profile Getters/Setters ---
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public double getWeightLbs() { return weightLbs; }
    public void setWeightLbs(double weightLbs) { this.weightLbs = weightLbs; }

    public int getHeightFeet() { return heightFeet; }
    public void setHeightFeet(int heightFeet) { this.heightFeet = heightFeet; }

    public int getHeightInches() { return heightInches; }
    public void setHeightInches(int heightInches) { this.heightInches = heightInches; }

    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    public String getActivityLevel() { return activityLevel; }
    public void setActivityLevel(String activityLevel) { this.activityLevel = activityLevel; }

    public String getGoalType() { return goalType; }
    public void setGoalType(String goalType) { this.goalType = goalType; }

    public int getCalorieTarget() { return calorieTarget; }
    public void setCalorieTarget(int calorieTarget) { this.calorieTarget = calorieTarget; }

    // --- Pantry Functions ---
    public List<PantryItem> getPantryItems() { return pantryItems; }

    public void addPantryItem(PantryItem item) { pantryItems.add(item); }

    // Removes an item by name (case-insensitive match)
    public void removePantryItem(String itemName) {
        pantryItems.removeIf(item -> item.getName().equalsIgnoreCase(itemName));
    }

    // --- Recipe Functions (Map with Calories) ---
    public Map<String, Integer> getSavedRecipes() {
        return savedRecipes;
    }

    public void addSavedRecipe(String recipeName, int calories) {
        savedRecipes.put(recipeName, calories);
    }

    public void removeSavedRecipe(String recipeName) {
        savedRecipes.remove(recipeName);
    }

    // Cache for recipe nutrition breakdown text (used for displaying saved recipe details)
    private Map<String, String> recipeCache = new HashMap<>();

    public void cacheRecipeInfo(String title, String breakdownText) {
        recipeCache.put(title, breakdownText);
    }

    public String getCachedRecipeInfo(String title) {
        return recipeCache.getOrDefault(title, null);
    }
}
