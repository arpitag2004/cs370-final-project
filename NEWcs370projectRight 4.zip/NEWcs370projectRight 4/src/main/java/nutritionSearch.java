import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class nutritionSearch {
    private static final String SPOON_API_KEY = "505c323ccad0410cba7df9a3ff1bd137";
    private static final String NUTRITIONIX_APP_ID = "da9255b4";
    private static final String NUTRITIONIX_APP_KEY = "306ed3bf85826cda3ea73fbb7a80e66a";

    // Attempts to retrieve nutrition info using Spoonacular, and falls back to Nutritionix if needed
    public static String getNutritionInfo(String ingredientName) {
        try {
            // 1. Try Spoonacular API (autocomplete to get ingredient ID)
            String cleanedQuery = ingredientName.trim().toLowerCase().replace(" ", "%20");
            String autoUrl = "https://api.spoonacular.com/food/ingredients/autocomplete?query=" +
                    cleanedQuery + "&number=1&apiKey=" + SPOON_API_KEY;

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest autoRequest = HttpRequest.newBuilder()
                    .uri(URI.create(autoUrl))
                    .GET()
                    .build();

            HttpResponse<String> autoResponse = client.send(autoRequest, HttpResponse.BodyHandlers.ofString());
            JSONArray autoResults = new JSONArray(autoResponse.body());

            // If a valid ID is returned, use it to get detailed nutrition info
            if (autoResults.length() > 0 && autoResults.getJSONObject(0).has("id")) {
                int id = autoResults.getJSONObject(0).getInt("id");
                String name = autoResults.getJSONObject(0).optString("name", ingredientName);

                String infoUrl = "https://api.spoonacular.com/food/ingredients/" + id +
                        "/information?amount=100&unit=gram&apiKey=" + SPOON_API_KEY;

                HttpRequest infoRequest = HttpRequest.newBuilder()
                        .uri(URI.create(infoUrl))
                        .GET()
                        .build();

                HttpResponse<String> infoResponse = client.send(infoRequest, HttpResponse.BodyHandlers.ofString());
                JSONObject info = new JSONObject(infoResponse.body());
                JSONObject nutrition = info.getJSONObject("nutrition");
                JSONArray nutrients = nutrition.getJSONArray("nutrients");

                // Extract specific macro nutrients
                double protein = 0, fat = 0, carbs = 0, calories = 0;
                for (int i = 0; i < nutrients.length(); i++) {
                    JSONObject n = nutrients.getJSONObject(i);
                    switch (n.getString("name")) {
                        case "Protein" -> protein = n.getDouble("amount");
                        case "Fat" -> fat = n.getDouble("amount");
                        case "Carbohydrates" -> carbs = n.getDouble("amount");
                        case "Calories" -> calories = n.getDouble("amount");
                    }
                }

                return String.format("Food: %s (per 100g)\nProtein: %.1fg\nFat: %.1fg\nCarbs: %.1fg\nCalories: %.1f",
                        name, protein, fat, carbs, calories);
            }
        } catch (Exception ignored) {
            // If Spoonacular fails, silently proceed to Nutritionix
        }

        // 2. Try Nutritionix API as fallback
        try {
            String body = new JSONObject().put("query", ingredientName).toString();
            String url = "https://trackapi.nutritionix.com/v2/natural/nutrients";

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("x-app-id", NUTRITIONIX_APP_ID)
                    .header("x-app-key", NUTRITIONIX_APP_KEY)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                    .build();

            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            JSONObject json = new JSONObject(response.body());
            JSONArray foods = json.getJSONArray("foods");

            if (foods.length() == 0) return "No data found.";

            // Extract nutrition info from the first matched food item
            JSONObject food = foods.getJSONObject(0);
            return String.format(
                    "Food: %s (%.1fg)\nProtein: %.1fg\nFat: %.1fg\nCarbs: %.1fg\nCalories: %.1f",
                    food.getString("food_name"),
                    food.getDouble("serving_weight_grams"),
                    food.getDouble("nf_protein"),
                    food.getDouble("nf_total_fat"),
                    food.getDouble("nf_total_carbohydrate"),
                    food.getDouble("nf_calories")
            );

        } catch (Exception e) {
            return "Error retrieving nutrition: " + e.getMessage();
        }
    }
}
