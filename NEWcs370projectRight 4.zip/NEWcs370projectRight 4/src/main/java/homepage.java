import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class homepage extends JFrame {
    private JButton recipesButton, pantryButton, myRecipesButton, goalsButton, profileButton;

    private JPanel cardPanel;
    private CardLayout cardLayout;

    private User currentUser;
    private Map<String, User> users;

    private RecipeManager recipeManager;

    // Color and font constants
    private static final Color PRIMARY_COLOR = new Color(210, 18, 46, 255);
    private static final Color BACKGROUND_COLOR = new Color(245, 250, 255);
    private static final Font HEADER_FONT = new Font("SansSerif", Font.BOLD, 16);

    public homepage(User currentUser, Map<String, User> users) {
        this.currentUser = currentUser;
        this.users = users;

        recipeManager = new RecipeManager();

        // Initialize navigation buttons
        recipesButton = createStyledButton("Recipes");
        myRecipesButton = createStyledButton("My Recipes");
        goalsButton = createStyledButton("Goals");
        profileButton = createCircularButtonWithImage("remmyprofile.png");
        pantryButton = createStyledButton("Pantry");

        // Setup CardLayout to switch between different pages
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        // Add all pages to the CardLayout
        cardPanel.add(createSearchPage(), "Search");
        cardPanel.add(MyListManager.buildRecipePage(currentUser, this::saveUsers, recipeManager), "Recipes");
        cardPanel.add(recipeManager.createMyRecipesPage(this), "MyRecipes");
        cardPanel.add(GoalsManager.buildGoalsPage(currentUser, this::saveUsers), "Goals");

        // Profile page setup with goal refresh logic
        cardPanel.add(new ProfilePage(currentUser, () -> {
            saveUsers();

            // Remove old Goals page
            for (Component comp : cardPanel.getComponents()) {
                if ("Goals".equals(comp.getName())) {
                    cardPanel.remove(comp);
                    break;
                }
            }

            // Add updated Goals page with refreshed calorie info
            JPanel updatedGoalsPage = GoalsManager.buildGoalsPage(currentUser, this::saveUsers);
            updatedGoalsPage.setName("Goals");
            cardPanel.add(updatedGoalsPage, "Goals");
        }, page -> cardLayout.show(cardPanel, page)).createProfilePanel(), "Profile");

        // Pantry page
        cardPanel.add(PantryItem.createPantryPage(currentUser, this::saveUsers), "Pantry");

        // Show default page
        cardLayout.show(cardPanel, "Search");

        // Button listeners for page navigation
        recipesButton.addActionListener(e -> cardLayout.show(cardPanel, "Recipes"));
        myRecipesButton.addActionListener(e -> cardLayout.show(cardPanel, "MyRecipes"));
        goalsButton.addActionListener(e -> cardLayout.show(cardPanel, "Goals"));
        profileButton.addActionListener(e -> cardLayout.show(cardPanel, "Profile"));
        pantryButton.addActionListener(e -> cardLayout.show(cardPanel, "Pantry"));

        // Setup top navigation bar
        JPanel topBar = new JPanel();
        topBar.setLayout(new BoxLayout(topBar, BoxLayout.X_AXIS));
        topBar.setBackground(PRIMARY_COLOR);
        topBar.add(recipesButton);
        topBar.add(myRecipesButton);
        topBar.add(pantryButton);
        topBar.add(goalsButton);
        topBar.add(Box.createHorizontalGlue());

        // Add profile button aligned to the right
        JPanel profilePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        profilePanel.setOpaque(false);
        profilePanel.add(profileButton);
        topBar.add(profilePanel);

        // Final frame setup
        setLayout(new BorderLayout());
        add(topBar, BorderLayout.NORTH);
        add(cardPanel, BorderLayout.CENTER);

        setTitle("DelishDish");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // Creates a styled button used for navigation
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(Color.WHITE);
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setFont(HEADER_FONT);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    // Creates a circular profile button with an image
    private JButton createCircularButtonWithImage(String resourcePath) {
        ImageIcon icon = null;
        try {
            icon = new ImageIcon(getClass().getResource(resourcePath));
        } catch (Exception e) {
            System.out.println("Failed to load profile image.");
        }

        Image scaledImage = icon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);

        JButton button = new JButton(new ImageIcon(scaledImage)) {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(getModel().isArmed() ? Color.LIGHT_GRAY : PRIMARY_COLOR);
                g.fillOval(0, 0, getSize().width - 1, getSize().height - 1);

                Graphics2D g2 = (Graphics2D) g.create();
                Shape clip = g2.getClip();
                g2.setClip(new java.awt.geom.Ellipse2D.Float(0, 0, getWidth(), getHeight()));
                g2.drawImage(scaledImage, 0, 0, getWidth(), getHeight(), null);
                g2.setClip(clip);
                g2.dispose();
                super.paintComponent(g);
            }

            @Override
            protected void paintBorder(Graphics g) {
                g.setColor(Color.BLACK);
                g.drawOval(0, 0, getSize().width - 1, getSize().height - 1);
            }

            @Override
            public boolean contains(int x, int y) {
                int radius = getWidth() / 2;
                int centerX = getWidth() / 2, centerY = getHeight() / 2;
                return Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2) <= Math.pow(radius, 2);
            }
        };

        button.setPreferredSize(new Dimension(50, 50));
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setToolTipText("Go to Profile");

        return button;
    }

    // Welcome screen shown on app launch
    private JPanel createSearchPage() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        JLabel label = new JLabel("Welcome to DelishDish!", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        panel.add(label, BorderLayout.CENTER);
        return panel;
    }

    // Loads saved users from disk
    private void loadUsers() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("users.dat"))) {
            users = (Map<String, User>) in.readObject();
        } catch (Exception e) {
            users = new HashMap<>();
        }
    }

    // Saves current users to disk
    private void saveUsers() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("users.dat"))) {
            out.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
