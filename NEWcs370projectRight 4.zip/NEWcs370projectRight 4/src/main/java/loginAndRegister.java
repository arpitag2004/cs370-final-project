import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class loginAndRegister extends JFrame {
    private JTextField loginUsernameField, registerUsernameField;
    private JPasswordField loginPasswordField, registerPasswordField;
    private JTextField firstNameField, lastNameField;
    private JLabel loginStatusLabel, registerStatusLabel;

    private CardLayout cardLayout;
    private JPanel mainPanel;
    private Map<String, User> users; // Stores registered users keyed by username

    public loginAndRegister() {
        loadUsers();  // Load user data from file
        setupUI();    // Initialize the user interface
    }

    // Set up the frame and attach login/register panels
    private void setupUI() {
        setTitle("Welcome to DelishDish");
        setSize(400, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLoginPanel(), "Login");
        mainPanel.add(createRegisterPanel(), "Register");

        add(mainPanel);
        setVisible(true);
    }

    // Login screen layout and functionality
    private JPanel createLoginPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(245, 250, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JLabel title = new JLabel("Login to DelishDish", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 25)));

        // Load Remmy image if available
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/remmy.png"));
            Image scaled = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaled));
            imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(imageLabel);
            panel.add(Box.createRigidArea(new Dimension(0, 20)));
        } catch (Exception e) {
            System.out.println("Remmy image load failed.");
        }

        // Username and password fields
        loginUsernameField = new JTextField();
        loginUsernameField.setMaximumSize(new Dimension(200, 40));
        loginUsernameField.setBorder(BorderFactory.createTitledBorder("Username"));
        panel.add(loginUsernameField);

        loginPasswordField = new JPasswordField();
        loginPasswordField.setMaximumSize(new Dimension(200, 40));
        loginPasswordField.setBorder(BorderFactory.createTitledBorder("Password"));
        panel.add(loginPasswordField);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.setBackground(new Color(255, 102, 102));
        loginButton.addActionListener(e -> handleLogin());
        panel.add(loginButton);

        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Switch to register panel
        JButton goToRegisterButton = new JButton("Create Account");
        goToRegisterButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        goToRegisterButton.setBackground(new Color(255, 102, 102));
        goToRegisterButton.addActionListener(e -> {
            clearRegisterFields();
            cardLayout.show(mainPanel, "Register");
        });
        panel.add(goToRegisterButton);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        loginStatusLabel = new JLabel(" ", SwingConstants.CENTER);
        loginStatusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginStatusLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        loginStatusLabel.setForeground(Color.RED);
        panel.add(loginStatusLabel);

        return panel;
    }

    // Registration screen layout and logic
    private JPanel createRegisterPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(245, 250, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        JLabel title = new JLabel("Create Account", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Registration input fields
        firstNameField = new JTextField();
        firstNameField.setMaximumSize(new Dimension(200, 40));
        firstNameField.setBorder(BorderFactory.createTitledBorder("First Name"));
        panel.add(firstNameField);

        lastNameField = new JTextField();
        lastNameField.setMaximumSize(new Dimension(200, 40));
        lastNameField.setBorder(BorderFactory.createTitledBorder("Last Name"));
        panel.add(lastNameField);

        registerUsernameField = new JTextField();
        registerUsernameField.setMaximumSize(new Dimension(200, 40));
        registerUsernameField.setBorder(BorderFactory.createTitledBorder("Username"));
        panel.add(registerUsernameField);

        registerPasswordField = new JPasswordField();
        registerPasswordField.setMaximumSize(new Dimension(200, 40));
        registerPasswordField.setBorder(BorderFactory.createTitledBorder("Password"));
        panel.add(registerPasswordField);

        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Register button
        JButton createAccountButton = new JButton("Create Account");
        createAccountButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        createAccountButton.setBackground(new Color(255, 102, 102));
        createAccountButton.addActionListener(e -> handleCreateAccount());
        panel.add(createAccountButton);

        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Return to login
        JButton backToLoginButton = new JButton("Back to Login");
        backToLoginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backToLoginButton.setBackground(new Color(255, 102, 102));
        backToLoginButton.addActionListener(e -> cardLayout.show(mainPanel, "Login"));
        panel.add(backToLoginButton);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        registerStatusLabel = new JLabel(" ", SwingConstants.CENTER);
        registerStatusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerStatusLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        registerStatusLabel.setForeground(Color.RED);
        panel.add(registerStatusLabel);

        return panel;
    }

    // Logic for validating login credentials
    private void handleLogin() {
        String username = loginUsernameField.getText().trim();
        String password = new String(loginPasswordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            loginStatusLabel.setForeground(Color.RED);
            loginStatusLabel.setText("Please enter username and password.");
            return;
        }

        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            loginStatusLabel.setForeground(new Color(0, 128, 0));
            loginStatusLabel.setText("Login successful!");
            dispose();
            new homepage(user, users); // Open homepage
        } else {
            loginStatusLabel.setForeground(Color.RED);
            loginStatusLabel.setText("Invalid username or password.");
        }
    }

    // Logic for creating a new user account
    private void handleCreateAccount() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String username = registerUsernameField.getText().trim();
        String password = new String(registerPasswordField.getPassword()).trim();

        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()) {
            registerStatusLabel.setForeground(Color.RED);
            registerStatusLabel.setText("Please fill in all fields.");
            return;
        }

        if (users.containsKey(username)) {
            registerStatusLabel.setForeground(Color.RED);
            registerStatusLabel.setText("Username already exists.");
        } else {
            User user = new User(firstName, lastName, username, password);
            users.put(username, user);
            saveUsers(); // Save updated user map to file

            // Auto-fill login fields for convenience
            loginUsernameField.setText(username);
            loginPasswordField.setText(password);
            loginStatusLabel.setForeground(new Color(0, 128, 0));
            loginStatusLabel.setText("Account created. You can log in.");
            cardLayout.show(mainPanel, "Login");
        }
    }

    // Clears the registration form fields
    private void clearRegisterFields() {
        firstNameField.setText("");
        lastNameField.setText("");
        registerUsernameField.setText("");
        registerPasswordField.setText("");
        registerStatusLabel.setText(" ");
    }

    // Load user map from local file
    private void loadUsers() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("users.dat"))) {
            users = (Map<String, User>) in.readObject();
        } catch (Exception e) {
            users = new HashMap<>(); // Start fresh if file not found or corrupted
        }
    }

    // Save user map to local file
    private void saveUsers() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("users.dat"))) {
            out.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Launch the login/register UI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(loginAndRegister::new);
    }
}