import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class PantryItem implements Serializable {
    private String name;
    private int quantity;
    private Date expirationDate;
    private String nutritionInfo;

    // Constructor to create a new pantry item
    public PantryItem(String name, int quantity, Date expirationDate) {
        this.name = name;
        this.quantity = quantity;
        this.expirationDate = expirationDate;
    }

    // Getters and setters
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public Date getExpirationDate() { return expirationDate; }

    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getNutritionInfo() { return nutritionInfo; }
    public void setNutritionInfo(String nutritionInfo) { this.nutritionInfo = nutritionInfo; }

    // Builds and returns the full Pantry page UI
    public static JPanel createPantryPage(User currentUser, Runnable saveUsersCallback) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 250, 255));

        // Top controls: search field and add button
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(panel.getBackground());

        JTextField searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(200, 30));
        searchField.setBorder(BorderFactory.createTitledBorder("Search Pantry"));

        JButton addButton = new JButton("+ Add Food Item");
        addButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        addButton.setFocusPainted(false);
        addButton.setBackground(new Color(230, 230, 250));
        addButton.setPreferredSize(new Dimension(160, 40));

        JPanel topControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        topControls.setBackground(panel.getBackground());
        topControls.add(searchField);
        topControls.add(addButton);
        topPanel.add(topControls, BorderLayout.WEST);
        panel.add(topPanel, BorderLayout.NORTH);

        // Grid for displaying pantry item cards
        JPanel pantryGrid = new JPanel(new GridLayout(0, 2, 15, 15));
        pantryGrid.setBackground(panel.getBackground());
        JScrollPane scrollPane = new JScrollPane(pantryGrid);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        panel.add(scrollPane, BorderLayout.CENTER);

        List<PantryItem> allItems = new ArrayList<>(currentUser.getPantryItems());

        // Label for expiration warnings (optional, not currently used)
        JLabel expiringSoonLabel = new JLabel();
        expiringSoonLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        expiringSoonLabel.setForeground(Color.RED);
        panel.add(expiringSoonLabel, BorderLayout.SOUTH);

        // Updates the pantry grid based on current user data
        Runnable updateGrid = () -> PantryItem.refreshPantryGrid(pantryGrid, currentUser, saveUsersCallback);

        // Add search functionality
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateGrid.run(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateGrid.run(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateGrid.run(); }
        });

        // Add item dialog and logic
        addButton.addActionListener(e -> {
            JTextField itemField = new JTextField();
            JTextField quantityField = new JTextField();
            JTextField daysField = new JTextField();

            Dimension boxSize = new Dimension(200, 30);
            itemField.setPreferredSize(boxSize);
            quantityField.setPreferredSize(boxSize);
            daysField.setPreferredSize(boxSize);

            JPanel inputPanel = new JPanel(new GridLayout(0, 1));
            inputPanel.add(new JLabel("Food Item:"));
            inputPanel.add(itemField);
            inputPanel.add(new JLabel("Quantity:"));
            inputPanel.add(quantityField);
            inputPanel.add(new JLabel("Days until expiration (optional, default 10):"));
            inputPanel.add(daysField);

            int result = JOptionPane.showConfirmDialog(panel, inputPanel, "Add Pantry Item", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                String itemName = itemField.getText().trim();
                int quantity;
                try {
                    quantity = Integer.parseInt(quantityField.getText().trim());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(panel, "Invalid quantity. Please enter a number.");
                    return;
                }

                int daysUntilExpire = 10;
                try {
                    daysUntilExpire = Integer.parseInt(daysField.getText().trim());
                } catch (Exception ignored) {}

                // Calculate expiration date
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, 0);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                cal.add(Calendar.DATE, daysUntilExpire);
                Date expireDate = cal.getTime();

                // Check for existing item with the same name and expiration date
                boolean found = false;
                for (PantryItem existing : allItems) {
                    if (existing.getName().equalsIgnoreCase(itemName) && existing.getExpirationDate().equals(expireDate)) {
                        existing.setQuantity(existing.getQuantity() + quantity);
                        found = true;
                        break;
                    }
                }

                // Add new item if not found
                if (!found) {
                    PantryItem item = new PantryItem(itemName, quantity, expireDate);
                    String nutrition = nutritionSearch.getNutritionInfo(itemName);
                    item.setNutritionInfo(nutrition);
                    currentUser.addPantryItem(item);
                    allItems.add(item);
                }

                saveUsersCallback.run();
                updateGrid.run();
            }
        });

        updateGrid.run();
        return panel;
    }

    // Refreshes the visual pantry grid with the latest item list
    public static void refreshPantryGrid(JPanel grid, User currentUser, Runnable saveUsersCallback) {
        grid.removeAll();
        List<PantryItem> sorted = new ArrayList<>(currentUser.getPantryItems());
        sorted.sort(Comparator.comparing(PantryItem::getExpirationDate));

        if (sorted.isEmpty()) {
            // Show message if no items exist
            JLabel empty = new JLabel("No pantry items yet.", SwingConstants.CENTER);
            empty.setFont(new Font("SansSerif", Font.PLAIN, 14));
            JPanel emptyCard = new JPanel();
            emptyCard.setPreferredSize(new Dimension(100, 100));
            emptyCard.setBackground(Color.WHITE);
            emptyCard.setLayout(new GridBagLayout());
            emptyCard.add(empty);
            grid.add(emptyCard);
        } else {
            // Create a card for each pantry item
            for (PantryItem item : sorted) {
                grid.add(createPantryCard(item, currentUser, saveUsersCallback, grid));
            }
        }

        grid.revalidate();
        grid.repaint();
    }

    // Creates a visual card for an individual pantry item
    public static JPanel createPantryCard(PantryItem item, User currentUser, Runnable saveUsersCallback, JPanel parentGrid) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(100, 100));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));

        // Highlight if the item is expiring soon
        long diff = item.getExpirationDate().getTime() - new Date().getTime();
        long daysLeft = diff / (1000 * 60 * 60 * 24);
        boolean isExpired = daysLeft < 0;
        if (daysLeft <= 3) {
            card.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
        }

        // Fetch or re-fetch nutrition info if missing
        String rawNutrition = item.getNutritionInfo();
        if (rawNutrition == null || rawNutrition.isEmpty() || rawNutrition.toLowerCase().contains("error")) {
            rawNutrition = nutritionSearch.getNutritionInfo(item.getName().trim().toLowerCase());
            item.setNutritionInfo(rawNutrition);
            saveUsersCallback.run();
        }

        final String nutrition = (rawNutrition.toLowerCase().startsWith("error") || rawNutrition.contains("No nutrition"))
                ? "Nutrition information not available."
                : rawNutrition;

        // Labels for item display
        JLabel nameLabel = new JLabel("<html><center>" + item.getName() + "</center></html>");
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel quantityLabel = new JLabel("Qty: " + item.getQuantity());
        quantityLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        quantityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel expireLabel = new JLabel();
        expireLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        expireLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        if (isExpired) {
            expireLabel.setText("Expired Item");
            expireLabel.setForeground(Color.RED);
        } else {
            expireLabel.setText("Exp: " + new SimpleDateFormat("MMM dd").format(item.getExpirationDate()));
        }

        card.add(Box.createVerticalStrut(5));
        card.add(nameLabel);
        card.add(quantityLabel);
        card.add(expireLabel);

        // Allow card to be clicked for more actions
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setToolTipText("Click to view nutrition and edit");
        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JPanel panel = new JPanel(new BorderLayout());
                JTextArea area = new JTextArea(nutrition);
                area.setEditable(false);
                area.setLineWrap(true);
                area.setWrapStyleWord(true);
                area.setBorder(BorderFactory.createTitledBorder("Nutrition Info"));
                panel.add(new JScrollPane(area), BorderLayout.CENTER);

                JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

                // Edit quantity button
                JButton editBtn = new JButton("Edit Quantity");
                editBtn.addActionListener(ev -> {
                    String input = JOptionPane.showInputDialog(card, "Enter new quantity:", item.getQuantity());
                    try {
                        int newQty = Integer.parseInt(input);
                        item.setQuantity(newQty);
                        saveUsersCallback.run();
                        refreshPantryGrid(parentGrid, currentUser, saveUsersCallback);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(card, "Invalid input.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                });

                // Remove item button
                JButton removeBtn = new JButton("Remove Item");
                removeBtn.addActionListener(ev -> {
                    currentUser.getPantryItems().remove(item);
                    saveUsersCallback.run();
                    refreshPantryGrid(parentGrid, currentUser, saveUsersCallback);
                });

                actionPanel.add(editBtn);
                actionPanel.add(removeBtn);
                panel.add(actionPanel, BorderLayout.SOUTH);

                // Show item details popup
                JOptionPane.showMessageDialog(card, panel, item.getName(), JOptionPane.PLAIN_MESSAGE);
            }
        });

        return card;
    }
}
