package Tests;

import java.net.http.*;
import java.net.URI;
import java.net.http.HttpRequest.BodyPublishers;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.Scanner;

public class nutritionSearchTest {

    // 🔍 API lookup method
    public static void getNutritionInfo(String userInput) throws Exception {
        // 🔐 Replace with your actual credentials
        String appId = "da9255b4";
        String appKey = "306ed3bf85826cda3ea73fbb7a80e66a";

        String url = "https://trackapi.nutritionix.com/v2/natural/nutrients";
        String jsonBody = new JSONObject().put("query", userInput).toString();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("x-app-id", appId)
                .header("x-app-key", appKey)
                .header("Content-Type", "application/json")
                .POST(BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        JSONObject result = new JSONObject(response.body());
        JSONArray foods = result.getJSONArray("foods");

        if (foods.length() > 0) {
            JSONObject food = foods.getJSONObject(0);
            String name = food.getString("food_name");
            double protein = food.getDouble("nf_protein");
            double fat = food.getDouble("nf_total_fat");
            double carbs = food.getDouble("nf_total_carbohydrate");
            double cals = food.getDouble("nf_calories");

            System.out.println("\nNutrition facts for: " + name);
            System.out.println("Protein: " + protein + "g");
            System.out.println("Fat: " + fat + "g");
            System.out.println("Carbs: " + carbs + "g");
            System.out.println("Calories: " + cals);

        } else {
            System.out.println("No nutrition data found for: " + userInput);
        }
    }

    // 🔽 MAIN METHOD — what you actually run
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a food (e.g. '1 banana'): ");
        String input = scanner.nextLine();

        try {
            getNutritionInfo(input);
        } catch (Exception e) {
            System.out.println("Something went wrong: " + e.getMessage());
        }
    }
}