import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class CalorieCalculator {

    // Shows a UI form to let the user input personal data and calculates calories based on that input
    public static int calculateCalories(JFrame parentFrame, JPanel goalGrid) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Input fields for calorie calculation
        JTextField ageField = new JTextField();
        JTextField weightField = new JTextField();
        JTextField feetField = new JTextField();
        JTextField inchesField = new JTextField();
        JComboBox<String> sexField = new JComboBox<>(new String[]{"Male", "Female"});
        JComboBox<String> activityField = new JComboBox<>(new String[]{
                "Sedentary", "Lightly active", "Moderately active", "Very active", "Super active"
        });
        JComboBox<String> goalField = new JComboBox<>(new String[]{"Lose", "Maintain", "Gain"});

        // Add input components to the panel
        panel.add(new JLabel("Age:"));
        panel.add(ageField);
        panel.add(new JLabel("Weight (lbs):"));
        panel.add(weightField);
        panel.add(new JLabel("Height - Feet:"));
        panel.add(feetField);
        panel.add(new JLabel("Height - Inches:"));
        panel.add(inchesField);
        panel.add(new JLabel("Sex:"));
        panel.add(sexField);
        panel.add(new JLabel("Activity Level:"));
        panel.add(activityField);
        panel.add(new JLabel("Goal:"));
        panel.add(goalField);

        // Show form in a confirmation dialog
        int result = JOptionPane.showConfirmDialog(parentFrame, panel, "Calculate Calories",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                // Parse and convert input
                int age = Integer.parseInt(ageField.getText().trim());
                double weight = Double.parseDouble(weightField.getText().trim());
                int feet = Integer.parseInt(feetField.getText().trim());
                int inches = Integer.parseInt(inchesField.getText().trim());

                double weightKg = weight * 0.453592;
                double heightCm = (feet * 12 + inches) * 2.54;
                String sex = sexField.getSelectedItem().toString().toLowerCase();
                String goal = goalField.getSelectedItem().toString().toLowerCase();
                int activityIndex = activityField.getSelectedIndex();

                // Calculate BMR using Mifflin-St Jeor Equation
                double bmr = sex.equals("male")
                        ? 10 * weightKg + 6.25 * heightCm - 5 * age + 5
                        : 10 * weightKg + 6.25 * heightCm - 5 * age - 161;

                // Apply activity multiplier
                double[] factors = {1.2, 1.375, 1.55, 1.725, 1.9};
                double tdee = bmr * factors[activityIndex];

                // Adjust based on goal
                if (goal.equals("lose")) tdee -= 500;
                if (goal.equals("gain")) tdee += 500;

                DecimalFormat df = new DecimalFormat("#");

                // Display the result in a card on the UI
                JPanel card = new JPanel();
                card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
                card.setBackground(Color.WHITE);
                card.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                card.setPreferredSize(new Dimension(200, 100));

                JLabel caloriesLabel = new JLabel("<html><center>Daily Calories:<br>" + df.format(tdee) + " kcal</center></html>");
                caloriesLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
                caloriesLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);

                card.add(Box.createVerticalStrut(10));
                card.add(caloriesLabel);
                card.add(Box.createVerticalStrut(10));

                goalGrid.add(card);
                goalGrid.revalidate();
                goalGrid.repaint();

                JOptionPane.showMessageDialog(parentFrame,
                        "Your daily calorie target is approximately " + df.format(tdee) + " kcal!",
                        "Calorie Result", JOptionPane.INFORMATION_MESSAGE);

                return (int)tdee;
            } catch (Exception ex) {
                // Handle bad input
                JOptionPane.showMessageDialog(parentFrame, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        return 0; // Return 0 if user cancels or an error occurs
    }

    // Calculates calories using the current User profile data without showing a UI
    public static int calculateCaloriesFromProfile(User user) {
        if (user == null) return 0;

        // Extract and convert user profile data
        int age = user.getAge();
        double weightKg = user.getWeightLbs() * 0.453592;
        int heightInches = user.getHeightFeet() * 12 + user.getHeightInches();
        double heightCm = heightInches * 2.54;
        String sex = user.getSex() != null ? user.getSex().toLowerCase().trim() : "";
        String goal = user.getGoalType() != null ? user.getGoalType().toLowerCase().trim() : "";
        String activity = user.getActivityLevel() != null ? user.getActivityLevel().toLowerCase().trim() : "";

        // If any essential field is missing, return 0
        if (age <= 0 || weightKg <= 0 || heightCm <= 0 || sex.isEmpty() || goal.isEmpty() || activity.isEmpty()) {
            return 0;
        }

        // Calculate BMR
        double bmr = sex.equals("male")
                ? 10 * weightKg + 6.25 * heightCm - 5 * age + 5
                : 10 * weightKg + 6.25 * heightCm - 5 * age - 161;

        // Determine activity multiplier
        double factor;
        switch (activity) {
            case "sedentary": factor = 1.2; break;
            case "lightly active": factor = 1.375; break;
            case "moderately active": factor = 1.55; break;
            case "very active": factor = 1.725; break;
            case "super active": factor = 1.9; break;
            default: factor = 1.2; break;
        }

        double tdee = bmr * factor;

        // Adjust based on weight goal
        if (goal.contains("lose")) tdee -= 500;
        else if (goal.contains("gain")) tdee += 500;

        int finalCalories = (int)tdee;

        user.setCalorieTarget(finalCalories); // Store calculated value in user profile
        return finalCalories;
    }

}
