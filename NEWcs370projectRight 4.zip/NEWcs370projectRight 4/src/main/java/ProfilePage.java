import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

public class ProfilePage {
    private final User currentUser;
    private final Runnable onProfileUpdated; // Callback to refresh profile-based data
    private final Consumer<String> onNavigate; // Callback to handle page navigation

    public ProfilePage(User currentUser, Runnable onProfileUpdated, Consumer<String> onNavigate) {
        this.currentUser = currentUser;
        this.onProfileUpdated = onProfileUpdated;
        this.onNavigate = onNavigate;
    }

    // Builds the full profile panel with input fields and buttons
    public JPanel createProfilePanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(new Color(245, 250, 255));
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(40, 100, 40, 100));

        JLabel profileTitle = new JLabel("My Profile", SwingConstants.CENTER);
        profileTitle.setFont(new Font("SansSerif", Font.BOLD, 28));
        profileTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        profileTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));

        JLabel welcome = new JLabel("Welcome, " + currentUser.getFirstName() + " " + currentUser.getLastName() + "!");
        welcome.setFont(new Font("SansSerif", Font.PLAIN, 18));
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Create input fields
        JTextField ageField = createLabeledField("Age");
        JTextField weightField = createLabeledField("Weight (lbs)");
        JTextField feetField = createLabeledField("Height (feet)");
        JTextField inchesField = createLabeledField("Height (inches)");

        // Create dropdowns
        JComboBox<String> sexBox = createLabeledDropdown(new String[]{"Male", "Female"}, "Sex");
        JComboBox<String> activityBox = createLabeledDropdown(new String[]{
                "Sedentary", "Lightly Active", "Moderately Active", "Very Active", "Super Active"
        }, "Activity Level");
        JComboBox<String> goalBox = createLabeledDropdown(new String[]{"Lose", "Maintain", "Gain"}, "Goal Type");

        // Pre-fill fields with current user's profile data
        if (currentUser.getAge() > 0) ageField.setText(String.valueOf(currentUser.getAge()));
        if (currentUser.getWeightLbs() > 0) weightField.setText(String.valueOf(currentUser.getWeightLbs()));
        if (currentUser.getHeightFeet() > 0) feetField.setText(String.valueOf(currentUser.getHeightFeet()));
        if (currentUser.getHeightInches() > 0) inchesField.setText(String.valueOf(currentUser.getHeightInches()));
        if (currentUser.getSex() != null) sexBox.setSelectedItem(currentUser.getSex());
        if (currentUser.getActivityLevel() != null) activityBox.setSelectedItem(currentUser.getActivityLevel());
        if (currentUser.getGoalType() != null) goalBox.setSelectedItem(currentUser.getGoalType());

        JButton saveBtn = new JButton("Save Profile Info");
        styleButton(saveBtn, new Color(33, 150, 243));

        JButton logoutBtn = new JButton("Logout");
        styleButton(logoutBtn, new Color(220, 53, 69));

        JLabel errorLabel = new JLabel(" ");
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        errorLabel.setForeground(Color.RED);
        errorLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));

        // Save button logic: validate input, update user object, and navigate to Goals page
        saveBtn.addActionListener(e -> {
            try {
                int age = Integer.parseInt(ageField.getText());
                double weight = Double.parseDouble(weightField.getText());
                int feet = Integer.parseInt(feetField.getText());
                int inches = Integer.parseInt(inchesField.getText());
                String sex = sexBox.getSelectedItem().toString();
                String activity = activityBox.getSelectedItem().toString();
                String goalType = goalBox.getSelectedItem().toString();

                if (age <= 0 || weight <= 0 || feet < 0 || inches < 0)
                    throw new NumberFormatException();

                // Update user profile
                currentUser.setAge(age);
                currentUser.setWeightLbs(weight);
                currentUser.setHeightFeet(feet);
                currentUser.setHeightInches(inches);
                currentUser.setSex(sex);
                currentUser.setActivityLevel(activity);
                currentUser.setGoalType(goalType);
                currentUser.setCalorieTarget(CalorieCalculator.calculateCaloriesFromProfile(currentUser));

                errorLabel.setText(" ");
                onProfileUpdated.run(); // Callback to refresh UI/data
                onNavigate.accept("Goals"); // Navigate to Goals page
            } catch (Exception ex) {
                errorLabel.setText("Please enter valid and complete info.");
            }
        });

        // Logout button logic: close current window and return to login screen
        logoutBtn.addActionListener(e -> {
            SwingUtilities.getWindowAncestor(logoutBtn).dispose();
            new loginAndRegister(); // Open login screen
        });

        // Add all components to content panel
        contentPanel.add(profileTitle);
        contentPanel.add(welcome);
        contentPanel.add(Box.createVerticalStrut(20));
        contentPanel.add(ageField);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(weightField);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(feetField);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(inchesField);
        contentPanel.add(Box.createVerticalStrut(20));
        contentPanel.add(sexBox);
        contentPanel.add(Box.createVerticalStrut(20));
        contentPanel.add(activityBox);
        contentPanel.add(Box.createVerticalStrut(20));
        contentPanel.add(goalBox);
        contentPanel.add(Box.createVerticalStrut(30));
        contentPanel.add(saveBtn);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(logoutBtn);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(errorLabel);

        // Make panel scrollable for smaller screens
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        return mainPanel;
    }

    // Utility to create labeled input text fields
    private JTextField createLabeledField(String title) {
        JTextField field = new JTextField();
        field.setMaximumSize(new Dimension(300, 50));
        field.setPreferredSize(new Dimension(300, 50));
        field.setBorder(BorderFactory.createTitledBorder(title));
        return field;
    }

    // Utility to create labeled dropdowns
    private JComboBox<String> createLabeledDropdown(String[] options, String title) {
        JComboBox<String> box = new JComboBox<>(options);
        box.setMaximumSize(new Dimension(300, 50));
        box.setPreferredSize(new Dimension(300, 50));
        box.setBorder(BorderFactory.createTitledBorder(title));
        return box;
    }

    // Utility to style buttons consistently
    private void styleButton(JButton button, Color bgColor) {
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(bgColor);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setMaximumSize(new Dimension(200, 40));
        button.setFocusPainted(false);
    }
}
