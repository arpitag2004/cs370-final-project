import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;

public class GoalsManager {
    private User currentUser;
    private JPanel goalGrid; // Panel where goal-related cards are displayed
    private JProgressBar calorieProgress; // Progress bar that tracks calories consumed

    // Constructor to initialize user and UI components
    public GoalsManager(User user, JPanel goalGrid, JProgressBar progressBar) {
        this.currentUser = user;
        this.goalGrid = goalGrid;
        this.calorieProgress = progressBar;
    }

    // Calculates and sets the user's calorie goal based on their profile data
    // Also updates the progress bar and displays the goal visually
    public void autoSetCaloriesFromProfile() {
        int calories = CalorieCalculator.calculateCaloriesFromProfile(currentUser);

        if (calories > 0) {
            calorieProgress.setMaximum(calories);
            calorieProgress.setValue(0);
            calorieProgress.setString("0 / " + calories + " calories");
            currentUser.setCalorieTarget(calories);

            // Display calorie goal card
            goalGrid.removeAll();
            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            card.setPreferredSize(new Dimension(200, 100));

            JLabel label = new JLabel("<html><center>Daily Calorie Goal:<br>" + calories + " kcal</center></html>");
            label.setFont(new Font("SansSerif", Font.BOLD, 14));
            label.setAlignmentX(Component.CENTER_ALIGNMENT);

            card.add(Box.createVerticalStrut(10));
            card.add(label);
            card.add(Box.createVerticalStrut(10));

            goalGrid.add(card);
            goalGrid.revalidate();
            goalGrid.repaint();
        } else {
            // Fallback if profile data is incomplete
            calorieProgress.setMaximum(1000);
            calorieProgress.setValue(0);
            calorieProgress.setString("Incomplete profile info");
        }
    }

    // Saves the user's overall fitness goal type (e.g., lose weight, gain muscle)
    public void saveGoal(String finalGoal) {
        if (finalGoal == null || finalGoal.isEmpty()) return;
        currentUser.setGoalType(finalGoal);
    }

    // Updates the progress bar when calories are consumed
    public void addCalories(int calories) {
        int newTotal = calorieProgress.getValue() + calories;

        // Prevent the progress bar from exceeding the maximum
        if (newTotal > calorieProgress.getMaximum()) {
            newTotal = calorieProgress.getMaximum();
        }

        calorieProgress.setValue(newTotal);
        calorieProgress.setString(newTotal + " / " + calorieProgress.getMaximum() + " calories");
    }

    // Builds the full Goals page UI, including the progress bar and calorie logging buttons
    public static JPanel buildGoalsPage(User currentUser, Runnable saveUsers) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setName("Goals");
        panel.setBackground(new Color(245, 250, 255)); // Light background

        // Section at the top showing the progress bar and calorie buttons
        JPanel caloriePanel = new JPanel(new BorderLayout());
        caloriePanel.setBackground(new Color(245, 250, 255));

        JProgressBar calorieProgress = new JProgressBar();
        calorieProgress.setStringPainted(true);
        calorieProgress.setMinimum(0);
        calorieProgress.setValue(0);

        // Buttons for logging calories
        JPanel progressControls = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addFromRecipeButton = new JButton("Add From Recipe");
        JButton manualAddButton = new JButton("Add Calories");

        progressControls.add(addFromRecipeButton);
        progressControls.add(manualAddButton);

        caloriePanel.add(calorieProgress, BorderLayout.CENTER);
        caloriePanel.add(progressControls, BorderLayout.EAST);

        panel.add(caloriePanel, BorderLayout.NORTH);

        // Area that shows the user's calorie goal card
        JPanel goalGrid = new JPanel(new GridLayout(0, 1, 10, 10));
        goalGrid.setBackground(new Color(245, 250, 255));
        JScrollPane scroll = new JScrollPane(goalGrid);
        scroll.setBorder(BorderFactory.createTitledBorder("Calorie Target"));

        panel.add(scroll, BorderLayout.CENTER);

        // Set up logic and UI using GoalsManager instance
        GoalsManager gm = new GoalsManager(currentUser, goalGrid, calorieProgress);
        gm.autoSetCaloriesFromProfile();

        // Action for logging calories from a saved recipe
        addFromRecipeButton.addActionListener(e -> {
            Map<String, Integer> recipes = currentUser.getSavedRecipes();
            if (recipes == null || recipes.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "No saved recipes to select. Please save some recipes first.");
                return;
            }

            // Let user pick a saved recipe to log calories
            String[] options = recipes.keySet().toArray(new String[0]);
            String selected = (String) JOptionPane.showInputDialog(
                    panel,
                    "Select a recipe you ate:",
                    "Choose Recipe",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (selected != null && !selected.trim().isEmpty()) {
                int calories = recipes.getOrDefault(selected, 300);
                gm.addCalories(calories);
                saveUsers.run();
                JOptionPane.showMessageDialog(panel, selected + " added: +" + calories + " calories!", "Food Logged", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Action for logging calories manually
        manualAddButton.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(panel, "Enter number of calories to add:");
            if (input != null && !input.trim().isEmpty()) {
                try {
                    int calories = Integer.parseInt(input.trim());
                    if (calories <= 0) throw new NumberFormatException();
                    gm.addCalories(calories);
                    saveUsers.run();
                    JOptionPane.showMessageDialog(panel, calories + " calories added manually!", "Food Logged", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Invalid calorie number. Please enter a positive integer.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        return panel;
    }
}
