import java.net.http.*;
import java.net.URI;
import org.json.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyListManager {
    // Holds user-specified and pantry-derived ingredients
    private static List<String> myList = new ArrayList<>();

    // The user's selected nutrition goal
    private static String userGoals = "";

    // Spoonacular API key used for HTTP requests
    private static final String API_KEY = "505c323ccad0410cba7df9a3ff1bd137";

    // Maps recipe titles to their Spoonacular IDs for quick lookup
    private static Map<String, Integer> recipeIdMap = new HashMap<>();

    // Simple structure to hold essential recipe data
    public record RecipeInfo(String title, String imageUrl, int id, String summary) {}

    // Combines manually typed and pantry ingredients for recipe search
    public static void setIngredientsAndGoals(String typedIngredients, List<String> pantryItems, String goal) {
        myList.clear();

        if (typedIngredients != null && !typedIngredients.isBlank()) {
            String[] typed = typedIngredients.split(",");
            for (String item : typed) {
                myList.add(item.trim().toLowerCase());
            }
        }

        for (String item : pantryItems) {
            if (!myList.contains(item.toLowerCase())) {
                myList.add(item.toLowerCase());
            }
        }

        userGoals = goal.toLowerCase().trim();
    }

    // Calls Spoonacular API to fetch matching recipes based on ingredients and goal
    public static List<RecipeInfo> fetchRecipes() throws Exception {
        List<RecipeInfo> recipes = new ArrayList<>();

        if (myList.isEmpty() || userGoals.isEmpty()) {
            return recipes;
        }

        String combinedQuery = String.join(" ", myList) + " " + userGoals;
        String encodedQuery = combinedQuery.replaceAll(" ", "%20");

        String apiUrl = "https://api.spoonacular.com/recipes/complexSearch"
                + "?query=" + encodedQuery
                + "&addRecipeInformation=true"
                + "&number=9"
                + "&apiKey=" + API_KEY;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .GET()
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        JSONObject jsonResponse = new JSONObject(response.body());
        if (!jsonResponse.has("results")) return recipes;

        JSONArray results = jsonResponse.getJSONArray("results");
        recipeIdMap.clear();

        for (int i = 0; i < results.length(); i++) {
            JSONObject recipe = results.getJSONObject(i);
            int id = recipe.getInt("id");
            String title = recipe.getString("title");
            String image = recipe.optString("image", "");
            String summary = recipe.optString("summary", "");

            recipeIdMap.put(title, id);
            recipes.add(new RecipeInfo(title, image, id, summary));
        }

        return recipes;
    }

    // Gets detailed nutritional info and ingredients for a specific recipe by title
    public static String getRecipeDetails(String title) throws Exception {
        if (!recipeIdMap.containsKey(title)) {
            return "Recipe ID not found for: " + title;
        }

        int recipeId = recipeIdMap.get(title);
        String apiUrl = "https://api.spoonacular.com/recipes/" + recipeId + "/information"
                + "?includeNutrition=true"
                + "&apiKey=" + API_KEY;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .GET()
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        JSONObject recipeInfo = new JSONObject(response.body());

        StringBuilder details = new StringBuilder();
        details.append("Title: ").append(recipeInfo.getString("title")).append("\n\n");

        details.append("Ingredients:\n");
        JSONArray ingredients = recipeInfo.getJSONArray("extendedIngredients");
        for (int i = 0; i < ingredients.length(); i++) {
            JSONObject ingredient = ingredients.getJSONObject(i);
            details.append("- ").append(ingredient.getString("original")).append("\n");
        }

        if (recipeInfo.has("nutrition")) {
            details.append("\nNutrition:\n");
            JSONArray nutrients = recipeInfo.getJSONObject("nutrition").getJSONArray("nutrients");

            for (int i = 0; i < nutrients.length(); i++) {
                JSONObject nutrient = nutrients.getJSONObject(i);
                String name = nutrient.getString("name").toLowerCase();

                if (name.contains("protein") || name.contains("fat") || name.contains("carbohydrate") || name.contains("calories")) {
                    details.append(nutrient.getString("name")).append(": ")
                            .append(nutrient.getDouble("amount")).append(" ")
                            .append(nutrient.getString("unit")).append("\n");
                }
            }
        }

        return details.toString();
    }

    // Returns the raw JSON object for a recipe ID if needed elsewhere
    public static JSONObject getRecipeInfoJson(int recipeId) throws Exception {
        String apiUrl = "https://api.spoonacular.com/recipes/" + recipeId + "/information"
                + "?includeNutrition=true"
                + "&apiKey=" + API_KEY;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .GET()
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return new JSONObject(response.body());
    }

    // Retrieves stored recipe ID or returns -1 if not found
    public static int getRecipeIdByTitle(String title) {
        return recipeIdMap.getOrDefault(title, -1);
    }

    // Attempts to extract calorie information from the full recipe details string
    private static int extractCalories(String recipeDetails) {
        try {
            for (String line : recipeDetails.split("\n")) {
                if (line.toLowerCase().contains("calories")) {
                    String[] parts = line.split(":");
                    return (int) Double.parseDouble(parts[1].trim().split(" ")[0]);
                }
            }
        } catch (Exception ignored) {}
        return 300; // Fallback calorie value if parsing fails
    }

    // GUI for the Recipe Finder page
    public static JPanel buildRecipePage(User currentUser, Runnable saveUsers, RecipeManager recipeManager) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 250, 255));

        // Title
        JLabel label = new JLabel("Recipe Finder", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        label.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panel.add(label, BorderLayout.NORTH);

        // Input section for entering ingredients and selecting goals
        JPanel inputSection = new JPanel();
        inputSection.setBackground(new Color(245, 250, 255));
        inputSection.setLayout(new BoxLayout(inputSection, BoxLayout.Y_AXIS));
        inputSection.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        topRow.setBackground(new Color(245, 250, 255));

        // Manual ingredient entry field
        JTextField ingredientField = new JTextField(15);
        ingredientField.setBorder(BorderFactory.createTitledBorder("Enter Ingredients"));
        topRow.add(ingredientField);

        JButton addManualButton = new JButton("Add");
        topRow.add(addManualButton);

        // Dropdown for pantry items
        JComboBox<String> pantryDropdown = new JComboBox<>();
        pantryDropdown.setPreferredSize(new Dimension(180, 50));
        pantryDropdown.setBorder(BorderFactory.createTitledBorder("Pantry Ingredients"));
        topRow.add(pantryDropdown);

        JButton addPantryButton = new JButton("Add Pantry");
        topRow.add(addPantryButton);

        JButton refreshPantryButton = new JButton("Reload");
        refreshPantryButton.setToolTipText("Refresh Pantry List");
        topRow.add(refreshPantryButton);

        // Goal selection dropdown
        JComboBox<String> goalDropdown = new JComboBox<>(new String[]{"", "Low Carb", "Muscle Gain", "Weight Loss", "High Protein", "Vegetarian", "Keto"});
        goalDropdown.setBorder(BorderFactory.createTitledBorder("Nutrition Goal"));
        goalDropdown.setPreferredSize(new Dimension(180, 50));
        topRow.add(goalDropdown);

        // Ingredient list display
        DefaultListModel<String> selectedIngredients = new DefaultListModel<>();
        JList<String> ingredientList = new JList<>(selectedIngredients);
        ingredientList.setVisibleRowCount(4);
        ingredientList.setBorder(BorderFactory.createTitledBorder("Selected Ingredients (double-click to remove)"));
        JScrollPane ingredientScroll = new JScrollPane(ingredientList);
        ingredientScroll.setPreferredSize(new Dimension(400, 80));

        // Allow ingredients to be removed on double-click
        ingredientList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = ingredientList.locationToIndex(e.getPoint());
                    if (index >= 0) selectedIngredients.remove(index);
                }
            }
        });

        // Reload pantry items from user's list
        Runnable reloadPantry = () -> {
            pantryDropdown.removeAllItems();
            currentUser.getPantryItems().stream()
                    .map(PantryItem::getName)
                    .distinct()
                    .sorted()
                    .forEach(pantryDropdown::addItem);
        };
        reloadPantry.run();

        // Button logic to add typed ingredient
        addManualButton.addActionListener(e -> {
            String typed = ingredientField.getText().trim();
            if (!typed.isEmpty() && !selectedIngredients.contains(typed)) {
                selectedIngredients.addElement(typed);
                ingredientField.setText("");
            }
            reloadPantry.run();
        });

        // Button logic to add from pantry dropdown
        addPantryButton.addActionListener(e -> {
            String item = (String) pantryDropdown.getSelectedItem();
            if (item != null && !selectedIngredients.contains(item)) {
                selectedIngredients.addElement(item);
            }
            reloadPantry.run();
        });

        refreshPantryButton.addActionListener(e -> reloadPantry.run());

        // Search button to trigger recipe lookup
        inputSection.add(topRow);
        inputSection.add(ingredientScroll);
        inputSection.add(Box.createVerticalStrut(10));
        JButton searchButton = new JButton("Find Recipes");
        searchButton.setPreferredSize(new Dimension(160, 40));
        inputSection.add(searchButton);

        // Panel to hold recipe result cards
        JPanel recipeGrid = new JPanel(new GridLayout(0, 2, 10, 10));
        recipeGrid.setBackground(new Color(245, 250, 255));
        JScrollPane scrollPane = new JScrollPane(recipeGrid);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Fetch and display recipes based on user input
        searchButton.addActionListener(e -> {
            try {
                List<String> selected = new ArrayList<>();
                for (int i = 0; i < selectedIngredients.size(); i++) selected.add(selectedIngredients.get(i));

                String goal = (String) goalDropdown.getSelectedItem();
                if (selected.isEmpty() || goal == null || goal.isEmpty()) {
                    JOptionPane.showMessageDialog(panel, "Please add ingredients and select a goal.", "Missing Info", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                setIngredientsAndGoals("", selected, goal);
                List<RecipeInfo> recipes = fetchRecipes();

                recipeGrid.removeAll();
                for (RecipeInfo info : recipes) {
                    JPanel card = new JPanel();
                    card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
                    card.setBackground(Color.WHITE);
                    card.setPreferredSize(new Dimension(220, 220));
                    card.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(Color.GRAY, 1),
                            BorderFactory.createEmptyBorder(10, 10, 10, 10)));

                    try {
                        ImageIcon icon = new ImageIcon(new java.net.URL(info.imageUrl()));
                        Image scaled = icon.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
                        JLabel img = new JLabel(new ImageIcon(scaled));
                        img.setAlignmentX(Component.CENTER_ALIGNMENT);
                        card.add(img);
                    } catch (Exception ex) {
                        card.add(new JLabel("No image"));
                    }

                    JLabel nameLabel = new JLabel("<html><center>" + info.title() + "</center></html>");
                    nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                    nameLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
                    card.add(nameLabel);

                    // Show nutrition details
                    JButton detailsBtn = new JButton("Details");
                    detailsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
                    detailsBtn.addActionListener(ev -> {
                        try {
                            String nutrition = getRecipeDetails(info.title());
                            JTextArea area = new JTextArea(nutrition);
                            area.setWrapStyleWord(true);
                            area.setLineWrap(true);
                            area.setEditable(false);
                            JOptionPane.showMessageDialog(panel, new JScrollPane(area), "Nutrition Info", JOptionPane.INFORMATION_MESSAGE);
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(panel, "Failed to load nutrition.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });

                    // Save recipe to user profile
                    JButton saveBtn = new JButton("Save");
                    saveBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
                    saveBtn.addActionListener(ev -> {
                        if (currentUser != null) {
                            try {
                                String details = getRecipeDetails(info.title());
                                int calories = extractCalories(details);
                                currentUser.addSavedRecipe(info.title(), calories);
                                saveUsers.run();
                                recipeManager.setCurrentUser(currentUser);
                                JOptionPane.showMessageDialog(panel, "Saved to My Recipes!");
                            } catch (Exception ex) {
                                JOptionPane.showMessageDialog(panel, "Failed to fetch recipe details.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    });

                    card.add(Box.createVerticalStrut(5));
                    card.add(detailsBtn);
                    card.add(saveBtn);
                    recipeGrid.add(card);
                }

                recipeGrid.revalidate();
                recipeGrid.repaint();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(panel, "Error retrieving recipes.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(inputSection, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }
}