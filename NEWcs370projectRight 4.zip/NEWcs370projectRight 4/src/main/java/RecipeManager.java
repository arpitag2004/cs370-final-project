import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class RecipeManager {
    private JPanel RecipePanel;
    private User currentUser;

    // Builds the main "My Recipes" page layout
    public JPanel createMyRecipesPage(JFrame parentFrame) {
        JPanel recipePage = new JPanel(new BorderLayout());
        recipePage.setBackground(new Color(245, 250, 255));

        // Grid layout to hold recipe cards
        RecipePanel = new JPanel(new GridLayout(0, 5, 10, 10));
        RecipePanel.setBackground(new Color(245, 250, 255));

        JScrollPane scrollPane = new JScrollPane(RecipePanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        recipePage.add(scrollPane, BorderLayout.CENTER);
        recipePage.add(createAddPanel(parentFrame), BorderLayout.NORTH); // Button panel at top

        return recipePage;
    }

    // Stores the current user and refreshes saved recipes
    public void setCurrentUser(User user) {
        this.currentUser = user;
        refreshSavedRecipes();
    }

    // Top section with "+ Add Recipe" button
    private JPanel createAddPanel(JFrame parentFrame) {
        JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addPanel.setBackground(new Color(245, 250, 255));

        JButton addButton = new JButton("+ Add Recipe");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addButton.addActionListener(e -> createRecipeDialog(parentFrame));

        addPanel.add(addButton);
        return addPanel;
    }

    // Modal dialog for creating a new recipe (name, description, ingredients)
    private void createRecipeDialog(JFrame parentFrame) {
        JTextField recipeName = new JTextField();
        JTextArea description = new JTextArea(3, 20); // Recipe instructions
        description.setLineWrap(true);
        JScrollPane descScroll = new JScrollPane(description);
        JTextField ingredients = new JTextField();

        JPanel inputPanel = new JPanel(new GridLayout(0, 1));
        inputPanel.add(new JLabel("Recipe Name:"));
        inputPanel.add(recipeName);
        inputPanel.add(new JLabel("Description:"));
        inputPanel.add(descScroll);
        inputPanel.add(new JLabel("Ingredients (comma-separated):"));
        inputPanel.add(ingredients);

        // Create recipe if fields are filled
        int result = JOptionPane.showConfirmDialog(parentFrame, inputPanel, "New Recipe",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION &&
                !recipeName.getText().isBlank() &&
                !ingredients.getText().isBlank()) {
            addRecipeCard(parentFrame, recipeName.getText(), description.getText(), ingredients.getText());
        }
    }

    // Adds a recipe card to the grid and stores it
    public void addRecipeCard(JFrame parentFrame, String name, String desc, String ingredientCSV) {
        String[] items = ingredientCSV.split(",");
        NutritionData total = new NutritionData();

        // Fetch and sum nutrition info for each ingredient
        for (String raw : items) {
            String item = raw.trim();
            if (item.isEmpty()) continue;

            String nutrition = nutritionSearch.getNutritionInfo(item);
            total.addFromText(nutrition); // Extract macros from text
        }

        // Format breakdown for viewing and caching
        StringBuilder summary = new StringBuilder();
        summary.append("Description:\n").append(desc).append("\n\n");
        summary.append("Ingredients:\n").append(ingredientCSV).append("\n\n");
        summary.append("Nutrition Info (Total):\n").append(total.summary());

        // Create and display card
        JPanel card = createRecipeCard(name, desc, total, summary.toString(), parentFrame);
        RecipePanel.add(card);
        RecipePanel.revalidate();
        RecipePanel.repaint();

        // Store with user for persistence
        if (currentUser != null) {
            currentUser.addSavedRecipe(name, (int) total.calories);
            currentUser.cacheRecipeInfo(name, summary.toString());
        }
    }

    // Creates an individual recipe card with click-to-view behavior
    private JPanel createRecipeCard(String name, String desc, NutritionData total, String breakdownText, JFrame parentFrame) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(150, 120));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel title = new JLabel("<html><center>" + name + "</center></html>");
        title.setFont(new Font("SansSerif", Font.BOLD, 13));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel calLabel = new JLabel("Calories: " + (int) total.calories);
        calLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        calLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(title);
        card.add(Box.createVerticalStrut(5));
        card.add(calLabel);

        // Click opens a dialog with full recipe info and edit options
        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JDialog viewer = new JDialog(parentFrame, name + " Details", true);
                viewer.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

                JPanel detailPanel = new JPanel(new BorderLayout());
                detailPanel.setPreferredSize(new Dimension(320, 260));

                JTextArea content = new JTextArea(breakdownText); // Shows all info
                content.setEditable(false);
                content.setWrapStyleWord(true);
                content.setLineWrap(true);
                content.setBorder(BorderFactory.createTitledBorder("Summary"));

                JButton editBtn = new JButton("Edit Recipe");
                editBtn.addActionListener(ev -> {
                    viewer.dispose();

                    // Prepopulate fields with original values
                    JTextField nameField = new JTextField(name);
                    JTextArea descArea = new JTextArea(desc, 3, 20);
                    descArea.setLineWrap(true);
                    JScrollPane descScroll = new JScrollPane(descArea);

                    // Extract ingredients from breakdown text
                    String ingredientsText = "";
                    if (breakdownText.contains("Ingredients:")) {
                        int start = breakdownText.indexOf("Ingredients:") + "Ingredients:".length();
                        int end = breakdownText.indexOf("Nutrition Info:");
                        if (end == -1) end = breakdownText.length();
                        ingredientsText = breakdownText.substring(start, end).trim().replaceAll("(?m)^-\\s*", "").replaceAll("\n+", ", ");
                    }

                    JTextField ingredientsField = new JTextField(ingredientsText);

                    JButton deleteBtn = new JButton("Delete");
                    JButton saveBtn = new JButton("Save Changes");

                    JPanel editPanel = new JPanel(new GridLayout(0, 1));
                    editPanel.add(new JLabel("Recipe Name:"));
                    editPanel.add(nameField);
                    editPanel.add(new JLabel("Instructions:"));
                    editPanel.add(descScroll);
                    editPanel.add(new JLabel("Ingredients (comma-separated):"));
                    editPanel.add(ingredientsField);

                    JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                    buttonRow.add(deleteBtn);
                    buttonRow.add(saveBtn);
                    editPanel.add(buttonRow);

                    JDialog editDialog = new JDialog(parentFrame, "Edit Recipe", true);
                    editDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                    editDialog.add(editPanel);
                    editDialog.setSize(320, 300);
                    editDialog.setLocationRelativeTo(parentFrame);

                    // Delete recipe
                    deleteBtn.addActionListener(del -> {
                        RecipePanel.remove(card);
                        RecipePanel.revalidate();
                        RecipePanel.repaint();
                        if (currentUser != null) currentUser.removeSavedRecipe(name);
                        editDialog.dispose();
                    });

                    // Save changes (replaces card)
                    saveBtn.addActionListener(ev2 -> {
                        if (!ingredientsField.getText().trim().isEmpty()) {
                            RecipePanel.remove(card);
                            RecipePanel.revalidate();
                            RecipePanel.repaint();
                            addRecipeCard(parentFrame, nameField.getText().trim(), descArea.getText().trim(), ingredientsField.getText().trim());
                        }
                        editDialog.dispose();
                    });

                    editDialog.setVisible(true);
                });

                JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                bottomPanel.add(editBtn);

                detailPanel.add(new JScrollPane(content), BorderLayout.CENTER);
                detailPanel.add(bottomPanel, BorderLayout.SOUTH);

                viewer.add(detailPanel);
                viewer.pack();
                viewer.setLocationRelativeTo(parentFrame);
                viewer.setVisible(true);
            }
        });

        return card;
    }

    // Loads saved recipes for the current user, showing nutrition and ingredients
    public void refreshSavedRecipes() {
        RecipePanel.removeAll();

        if (currentUser != null) {
            Map<String, Integer> saved = currentUser.getSavedRecipes();
            for (String title : saved.keySet()) {
                int id = MyListManager.getRecipeIdByTitle(title);

                if (id != -1) {
                    try {
                        JSONObject recipeInfo = MyListManager.getRecipeInfoJson(id);
                        StringBuilder breakdown = new StringBuilder();
                        NutritionData total = new NutritionData();

                        breakdown.append("Ingredients:\n");
                        JSONArray ingredients = recipeInfo.getJSONArray("extendedIngredients");
                        for (int i = 0; i < ingredients.length(); i++) {
                            JSONObject ing = ingredients.getJSONObject(i);
                            breakdown.append("- ").append(ing.getString("original")).append("\n");
                        }

                        breakdown.append("\nNutrition Info:\n");
                        JSONArray nutrients = recipeInfo.getJSONObject("nutrition").getJSONArray("nutrients");
                        for (int i = 0; i < nutrients.length(); i++) {
                            JSONObject nutrient = nutrients.getJSONObject(i);
                            String name = nutrient.getString("name").toLowerCase();
                            if (name.contains("protein") || name.contains("fat") || name.contains("carbohydrate") || name.contains("calories")) {
                                double amount = nutrient.getDouble("amount");
                                String unit = nutrient.getString("unit");
                                breakdown.append(nutrient.getString("name")).append(": ").append(amount).append(" ").append(unit).append("\n");
                            }
                        }

                        total.addFromText(breakdown.toString());
                        String summary = recipeInfo.optString("summary", "");

                        JPanel card = createRecipeCard(title, summary, total, breakdown.toString(), null);
                        RecipePanel.add(card);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JPanel fallbackCard = createRecipeCard(title, "", new NutritionData(), "Saved calories: " + saved.get(title), null);
                        RecipePanel.add(fallbackCard);
                    }
                } else {
                    // fallback: use cached nutrition if available
                    String cached = currentUser.getCachedRecipeInfo(title);
                    if (cached != null) {
                        NutritionData total = new NutritionData();
                        total.addFromText(cached);
                        JPanel cachedCard = createRecipeCard(title, "", total, cached, null);
                        RecipePanel.add(cachedCard);
                    } else {
                        JPanel fallbackCard = createRecipeCard(title, "", new NutritionData(), "Saved calories: " + saved.get(title), null);
                        RecipePanel.add(fallbackCard);
                    }
                }
            }
        }

        RecipePanel.revalidate();
        RecipePanel.repaint();
    }

    // Helper class to hold and accumulate macro values
    static class NutritionData {
        double protein = 0, fat = 0, carbs = 0, calories = 0;

        // Extracts values from nutrition breakdown text
        public void addFromText(String text) {
            String[] lines = text.split("\n");
            for (String line : lines) {
                String[] parts = line.split(":");
                if (parts.length < 2) continue;
                String key = parts[0].trim().toLowerCase();
                try {
                    double value = Double.parseDouble(parts[1].replaceAll("[^0-9.]", ""));
                    if (key.contains("protein")) protein += value;
                    else if (key.contains("fat")) fat += value;
                    else if (key.contains("carb")) carbs += value;
                    else if (key.contains("calories")) calories += value;
                } catch (Exception ignored) {}
            }
        }

        public String summary() {
            return String.format("Protein: %.1fg\nFat: %.1fg\nCarbs: %.1fg\nCalories: %.1f", protein, fat, carbs, calories);
        }
    }
}
